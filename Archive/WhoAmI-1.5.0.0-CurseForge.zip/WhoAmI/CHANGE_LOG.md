# Who Am I? :: Change Log

* 2024-1006: 1.5.0 (LisiasT) for KSP 1.12.5
	+ Initial version under LisiasT's stewardship.
* 2021-0708: 1.4.0 (maja) for KSP 1.12.5
	+ Changes
		- KSP 1.12+ compatibility
* 2021-0207: 1.3.0 (maja) for KSP 1.11.2
	+ KSP 1.11+ compatibility
* 2020-0720: 1.2.0 (maja) for KSP 1.10.1
	+ KSP 1.10+ compatibility
* 2019-1020: 1.1.0 (maja) for KSP 1.8.1
	+ KSP 1.8+ compatibility
* 2019-0603: 1.0.8 (maja) for KSP 1.7.3
	+ Recompile for KSP 1.7.1
* 2019-0428: 1.0.7 (maja) for KSP 1.7.0
	+ Recompile for KSP 1.7
* 2018-1019: 1.0.6 (maja) for KSP 1.5.1
	+ Recompile for KSP 1.5
* 2018-0314: 1.0.5 (maja) for KSP 1.4.1
	+ Recompile for KSP 1.4.1
* 2017-1011: 1.0.4 (maja) for KSP 1.3.1
	+ Recompile for KSP 1.3.1
* 2017-0529: 1.0.3 (RealGecko) for KSP 1.3.0
	+ Added kerbonaut level info
	+ Messages are shown via ScreenMessages
	+ Modifier Key + B brings up transfer dialog
* 2016-1012: 1.0.2 (RealGecko) for KSP 1.2.2
	+ Recompile for KPS 1.2
* 2016-0710: 1.0.1 (RealGecko) for KSP 1.1.3
	+ For KSP 1.1.3
	+ Label is hidden while all GUI is hidden (F2 by default)
	+ Label is hidden after four seconds after appearing
	+ Label is not taking full screen width
	+ Module name displayed correctly
* 2016-0706: 1.0.0 (RealGecko) for KSP 1.1.3
	+ KSP 1.1.3
